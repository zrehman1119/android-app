package com.example.user.test.feature;

import android.app.ProgressDialog;
import android.content.Context;
import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.ProtocolException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.Iterator;

import javax.net.ssl.HttpsURLConnection;

public class MainActivity extends AppCompatActivity {


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


    }

    /** Called when the user taps the Send button */
    public void sendMessage(View view) {
        new PostClass().execute();

    }


    private class PostClass extends AsyncTask<String, Void, Void> {
        TextView outputView = (TextView) findViewById(R.id.showOutput);
        protected void onPreExecute(){

        }
        @Override
        protected Void doInBackground(String... params) {
            try {
                EditText username = (EditText) findViewById(R.id.username);
                EditText password = (EditText) findViewById(R.id.password);
                EditText role = (EditText) findViewById(R.id.role);
                String url = "http://192.168.43.109:8080/Assignment-3/saveUser";
                URL obj = new URL(url);
                JSONObject data = new JSONObject();
                HttpURLConnection con = (HttpURLConnection) obj.openConnection();

                // Setting basic post request
                con.setRequestMethod("POST");
                con.setRequestProperty("Accept-Language", "en-US,en;q=0.5");
                con.setRequestProperty("Content-Type","application/json");

                data.put("username", username.getText().toString());
                data.put("password", password.getText().toString());
                data.put("type", role.getText().toString());
                //String postJsonData = "{\"username\":\"ZA\",\"password\":\"3456\",\"type\":\"Teacher\"}";

                // Send post request
                con.setDoOutput(true);
                DataOutputStream wr = new DataOutputStream(con.getOutputStream());
                wr.writeBytes(data.toString());

                wr.flush();
                wr.close();

                int responseCode = con.getResponseCode();


                BufferedReader in = new BufferedReader(
                        new InputStreamReader(con.getInputStream()));
                String output;
                StringBuffer response = new StringBuffer();

                while ((output = in.readLine()) != null) {
                    response.append(output);
                }
                in.close();


                //printing result from response
                outputView.setText(data.toString()+response.toString());


            } catch (Exception e) {
                // TODO Auto-generated catch block
                e.printStackTrace();
            }
            return null;
        }
        protected void onPostExecute(String response) {


        }
    }



}

